A Pen created at CodePen.io. You can find this one at https://codepen.io/AbbyNZ/pen/BOoYeB.

 My first tribute page. A responsive web design project of freeCodeCamp.